import os


def _env_int(name, default):
    value = os.getenv(name)
    return int(value) if value else default


def _db_config_from_env(prefix):
    host = os.getenv(f"{prefix}_HOST")
    user = os.getenv(f"{prefix}_USER")
    password = os.getenv(f"{prefix}_PASSWORD")
    database = os.getenv(f"{prefix}_DATABASE")
    port = _env_int(f"{prefix}_PORT", 3306)

    if not all([host, user, password, database]):
        return None

    return {
        "host": host,
        "port": port,
        "user": user,
        "password": password,
        "database": database,
    }


def _db_network_override_from_env(prefix):
    host = os.getenv(f"{prefix}_HOST")
    port = os.getenv(f"{prefix}_PORT")
    if not host and not port:
        return None
    return {
        "host": host,
        "port": int(port) if port else None,
    }


def _env_str(name, default=None):
    value = os.getenv(name)
    return value if value else default


DB_CONFIG = _db_config_from_env("DB")

BUCKET = "bidgely-smud-itron-uat-external"
BASE_PREFIX = "solar_usage_data/duration=5min/"

# Per-pilot S3 configuration overrides. Replace values below with the real bucket/prefix for each pilot.
PILOT_S3_PREFIXES = {
    10014: {"bucket": "bidgely-smud-itron-uat-external", "base_prefix": "solar_usage_data/duration=5min/"},
    10118: {"bucket": "bidgely-pecan-itron-uat-external", "base_prefix": "solar_usage_data/duration=15min/"},
    10223: {"bucket": "bidgely-luma-prod-external", "base_prefix": "solar_usage_data/duration=15min/"},
}

# Per-pilot export targets (where missing files, charts and CSVs should be uploaded).
# If a pilot isn't listed here, the global MISSING_EXPORT_S3_URI will be used.
PILOT_EXPORT_S3 = {
    10014: "s3://bidgely-artifacts2/Murali_Users/SMUD",
    10118: "s3://bidgely-artifacts2/Murali_Users/PECAN",
    10223: "s3://bidgely-artifacts2/Murali_Users/LUMA",
}

# Optional report variants for a pilot. Variants reuse the same pilot id and DB
# configuration, but can point to a different source/export path and display name.
PILOT_REPORT_VARIANTS = {
    10118: [
        {
            "name": "PECAN UAT",
        },
        {
            "name": "PECAN PRE",
            "s3": {
                "bucket": "bidgely-pecan-itron-uat-external",
                "base_prefix": "pre_solar_usage_data/duration=15min/",
            },
            "export_s3": "s3://bidgely-artifacts2/Murali_Users/PECAN_PRE",
        },
    ],
}

CHART_IMAGE_BUCKET = _env_str("CHART_IMAGE_BUCKET", "bidgely-email-images-nonprod")
CHART_IMAGE_PREFIX = _env_str("CHART_IMAGE_PREFIX", "Murali_Images")
CHART_CLOUDFRONT_BASE_URL = _env_str("CHART_CLOUDFRONT_BASE_URL", "https://d13hc4rsp6iv99.cloudfront.net")

# Human-friendly pilot names for display in reports
PILOT_NAMES = {
    10014: "SMUD UAT",
    10118: "PECAN UAT",
    10223: "LUMA PROD",
}

# Hourly notification trigger thresholds. Mode can be:
# - "count": trigger when missing users >= value
# - "percent": trigger when missing users / expected users >= value
PILOT_HOURLY_TRIGGER_THRESHOLDS = {
    10014: {"mode": "count", "value": 1},
    10118: {"mode": "percent", "value": 0.20},
    10223: {"mode": "count", "value": 2},
}

# Per-pilot Secrets Manager ARNs for DB credentials. Add ARN for production pilots (e.g. LUMA).
# Example:
# PILOT_DB_SECRET_ARNS = {10223: 'arn:aws:secretsmanager:us-east-1:123456789012:secret:luma-prod-db-xxxx'}
PILOT_DB_SECRET_ARNS = {
    # add entries as needed
    10223: 'arn:aws:secretsmanager:us-east-1:189675173661:secret:luma-prod-db-0cwqpd'
}

# Per-pilot direct DB configuration overrides. These are useful when a pilot
# needs a different host/IP or credential set and no Secrets Manager ARN is
# available for that environment.
PILOT_DB_CONFIGS = {
    10014: _db_config_from_env("PILOT_10014_DB"),
    10118: _db_config_from_env("PILOT_10118_DB"),
    10223: _db_config_from_env("PILOT_10223_DB"),
}

# Optional host/port-only overrides for SSH tunnels while still using either
# per-pilot secrets or full DB credentials from the selected source.
PILOT_DB_NETWORK_OVERRIDES = {
    10014: _db_network_override_from_env("PILOT_10014_DB_TUNNEL"),
    10118: _db_network_override_from_env("PILOT_10118_DB_TUNNEL"),
    10223: _db_network_override_from_env("PILOT_10223_DB_TUNNEL"),
}

OUTPUT_DIR = "output"

# SQS queue used for MiniDisagg processing status
SQS_QUEUE_URL = "https://sqs.us-west-2.amazonaws.com/189675173661/MiniDisaggGbTempDataReadyEventPyAmi-uat-itron"
SQS_REGION = "us-west-2"

# Google Chat notification settings (env-driven)
GCHAT_ENABLED = os.getenv("GCHAT_ENABLED", "false").lower() == "true"
GCHAT_WEBHOOK_URL = os.getenv("GCHAT_WEBHOOK_URL", "")
GCHAT_TIMEOUT_SECONDS = int(os.getenv("GCHAT_TIMEOUT_SECONDS", "10"))

# Missing-user report export target
MISSING_EXPORT_ENABLED = os.getenv("MISSING_EXPORT_ENABLED", "true").lower() == "true"
MISSING_EXPORT_S3_URI = os.getenv("MISSING_EXPORT_S3_URI", "s3://bidgely-artifacts2/Murali_Users/")

# User API + weather-data classification settings
USER_API_BASE_URL = os.getenv("USER_API_BASE_URL", "https://api-server-itron-uat.bidgely.com/v2.0/users/")
USER_API_TOKEN_ENV = os.getenv("USER_API_TOKEN_ENV", "USER_API_BEARER_TOKEN")
WEATHER_DATA_BUCKET = os.getenv("WEATHER_DATA_BUCKET", "bidgely-data-warehouse-uat")
WEATHER_DATA_PREFIX = os.getenv(
    "WEATHER_DATA_PREFIX",
    "weather-data/weather-data-raw/v3/weather_data_type=FORECAST/duration=1h/country=US",
)
WEATHER_LOOKUP_MODE = os.getenv("WEATHER_LOOKUP_MODE", "api")
WEATHER_REDSHIFT_HOST = os.getenv("WEATHER_REDSHIFT_HOST")
WEATHER_REDSHIFT_PORT = _env_int("WEATHER_REDSHIFT_PORT", 5439)
WEATHER_REDSHIFT_DATABASE = os.getenv("WEATHER_REDSHIFT_DATABASE", "bdw")
WEATHER_REDSHIFT_USER = os.getenv("WEATHER_REDSHIFT_USER")
WEATHER_REDSHIFT_PASSWORD = os.getenv("WEATHER_REDSHIFT_PASSWORD")
WEATHER_REDSHIFT_QUERY_TEMPLATE = os.getenv(
    "WEATHER_REDSHIFT_QUERY_TEMPLATE",
    "select distinct zip from home_meta_data where pilot_id = {pilot_id};",
)

# Optional per-pilot weather-check configuration. Each pilot can use its own
# user API URL, bearer-token env var name, weather bucket, and weather prefix.
PILOT_WEATHER_CONFIGS = {
    10014: {
        "lookup_mode": _env_str("PILOT_10014_WEATHER_LOOKUP_MODE", "redshift"),
        "api_base_url": _env_str("PILOT_10014_USER_API_BASE_URL", USER_API_BASE_URL),
        "token_env": _env_str("PILOT_10014_USER_API_TOKEN_ENV", USER_API_TOKEN_ENV),
        "weather_bucket": _env_str("PILOT_10014_WEATHER_DATA_BUCKET", WEATHER_DATA_BUCKET),
        "weather_prefix": _env_str("PILOT_10014_WEATHER_DATA_PREFIX", WEATHER_DATA_PREFIX),
        "redshift_host": _env_str("PILOT_10014_WEATHER_REDSHIFT_HOST", WEATHER_REDSHIFT_HOST),
        "redshift_port": _env_int("PILOT_10014_WEATHER_REDSHIFT_PORT", WEATHER_REDSHIFT_PORT),
        "redshift_database": _env_str("PILOT_10014_WEATHER_REDSHIFT_DATABASE", WEATHER_REDSHIFT_DATABASE),
        "redshift_user": _env_str("PILOT_10014_WEATHER_REDSHIFT_USER", WEATHER_REDSHIFT_USER),
        "redshift_password": _env_str("PILOT_10014_WEATHER_REDSHIFT_PASSWORD", WEATHER_REDSHIFT_PASSWORD),
        "redshift_query_template": _env_str(
            "PILOT_10014_WEATHER_REDSHIFT_QUERY_TEMPLATE",
            WEATHER_REDSHIFT_QUERY_TEMPLATE,
        ),
    },
    10118: {
        "lookup_mode": _env_str("PILOT_10118_WEATHER_LOOKUP_MODE", "redshift"),
        "api_base_url": _env_str("PILOT_10118_USER_API_BASE_URL", USER_API_BASE_URL),
        "token_env": _env_str("PILOT_10118_USER_API_TOKEN_ENV", USER_API_TOKEN_ENV),
        "weather_bucket": _env_str("PILOT_10118_WEATHER_DATA_BUCKET", WEATHER_DATA_BUCKET),
        "weather_prefix": _env_str("PILOT_10118_WEATHER_DATA_PREFIX", WEATHER_DATA_PREFIX),
        "redshift_host": _env_str("PILOT_10118_WEATHER_REDSHIFT_HOST", WEATHER_REDSHIFT_HOST),
        "redshift_port": _env_int("PILOT_10118_WEATHER_REDSHIFT_PORT", WEATHER_REDSHIFT_PORT),
        "redshift_database": _env_str("PILOT_10118_WEATHER_REDSHIFT_DATABASE", WEATHER_REDSHIFT_DATABASE),
        "redshift_user": _env_str("PILOT_10118_WEATHER_REDSHIFT_USER", WEATHER_REDSHIFT_USER),
        "redshift_password": _env_str("PILOT_10118_WEATHER_REDSHIFT_PASSWORD", WEATHER_REDSHIFT_PASSWORD),
        "redshift_query_template": _env_str(
            "PILOT_10118_WEATHER_REDSHIFT_QUERY_TEMPLATE",
            WEATHER_REDSHIFT_QUERY_TEMPLATE,
        ),
    },
    10223: {
        "lookup_mode": _env_str("PILOT_10223_WEATHER_LOOKUP_MODE", WEATHER_LOOKUP_MODE),
        "api_base_url": _env_str("PILOT_10223_USER_API_BASE_URL", USER_API_BASE_URL),
        "token_env": _env_str("PILOT_10223_USER_API_TOKEN_ENV", USER_API_TOKEN_ENV),
        "weather_bucket": _env_str("PILOT_10223_WEATHER_DATA_BUCKET", WEATHER_DATA_BUCKET),
        "weather_prefix": _env_str("PILOT_10223_WEATHER_DATA_PREFIX", WEATHER_DATA_PREFIX),
        "redshift_host": _env_str("PILOT_10223_WEATHER_REDSHIFT_HOST", WEATHER_REDSHIFT_HOST),
        "redshift_port": _env_int("PILOT_10223_WEATHER_REDSHIFT_PORT", WEATHER_REDSHIFT_PORT),
        "redshift_database": _env_str("PILOT_10223_WEATHER_REDSHIFT_DATABASE", WEATHER_REDSHIFT_DATABASE),
        "redshift_user": _env_str("PILOT_10223_WEATHER_REDSHIFT_USER", WEATHER_REDSHIFT_USER),
        "redshift_password": _env_str("PILOT_10223_WEATHER_REDSHIFT_PASSWORD", WEATHER_REDSHIFT_PASSWORD),
        "redshift_query_template": _env_str(
            "PILOT_10223_WEATHER_REDSHIFT_QUERY_TEMPLATE",
            WEATHER_REDSHIFT_QUERY_TEMPLATE,
        ),
    },
}

# Performance tuning knobs
S3_MAX_POOL_CONNECTIONS = _env_int("S3_MAX_POOL_CONNECTIONS", 64)
S3_CONNECT_TIMEOUT = _env_int("S3_CONNECT_TIMEOUT", 10)
S3_READ_TIMEOUT = _env_int("S3_READ_TIMEOUT", 60)
S3_MAX_RETRIES = _env_int("S3_MAX_RETRIES", 3)
S3_HOUR_READ_WORKERS = _env_int("S3_HOUR_READ_WORKERS", 16)
DATE_PROCESS_WORKERS = _env_int("DATE_PROCESS_WORKERS", 24)
WEATHER_S3_CHECK_WORKERS = _env_int("WEATHER_S3_CHECK_WORKERS", 32)

# Optional per-pilot AWS profile overrides so mixed UAT/prod runs can use the
# right identity for each pilot's S3/SQS access.
PILOT_AWS_PROFILES = {
    10014: _env_str("PILOT_10014_AWS_PROFILE"),
    10118: _env_str("PILOT_10118_AWS_PROFILE"),
    10223: _env_str("PILOT_10223_AWS_PROFILE"),
}

# Optional per-pilot export/write AWS profile overrides so a pilot can read
# source data with one identity and write report artifacts with another.
PILOT_EXPORT_AWS_PROFILES = {
    10014: _env_str("PILOT_10014_EXPORT_AWS_PROFILE"),
    10118: _env_str("PILOT_10118_EXPORT_AWS_PROFILE"),
    10223: _env_str("PILOT_10223_EXPORT_AWS_PROFILE"),
}
